/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int sisi;
    int luas, panjang, lebar;
    int phi = 3.14;
    int r = luas;
    string selanjutnya;
    
  cout << endl;
  cout << "======================================" << endl;
  cout << "       MENGHITUNG LUAS PERSEGI" << endl;
  cout << "======================================" << endl << endl;
  cout << "      MASUKAN SISI PERSEGI = ";
  cin>>sisi;
  cout << "      HASIL LUAS PERSEGI = "<< sisi * sisi << endl;
  cout << "======================================" << endl;
  cout << endl;

  cout << " ketik apa saja untuk melanjutkan : ";
  cin>>selanjutnya;
  cout << endl;
    
  cout << "======================================" << endl;
  cout << "   MENGHITUNG LUAS PERSEGI PANJANG" << endl;
  cout << "======================================" << endl << endl;
  cout << "   MASUKAN PANJANG = "; 
  cin>>panjang;
  cout << "   MASUKAN LEBAR =";
  cin>>lebar;
  cout << " HASIL LUAS PERSEGI PANJANG = " << panjang * lebar << endl;
  cout << "=======================================" << endl;
  cout << endl;

  cout << " ketik apa saja untuk melanjutkan : ";
  cin>>selanjutnya;
  cout << endl;
  
  cout << "========================================" << endl;
  cout << "       MENGHITUNG LUAS LINGKARAN " << endl;
  cout << "========================================" << endl << endl;
  cout << "      MASUKAN JARI JARI LINGKARAN = ";
  cin >> r;
  cout << "      HASIL LUAS LINGKARAN = " << 3.14 * r * r << endl;
  cout << "========================================" << endl;


return 0;
}
